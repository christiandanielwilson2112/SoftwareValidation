package org.apache.commons.mail;

public class EmailMock extends SimpleEmail{
    public String sendMimeMessage()
    	       throws EmailException
    	    {
    	        try
    	        {
    	            return this.message.getMessageID();
    	        }
    	        catch (Throwable t)
    	        {
    	            String msg = "Sending the email to the following server failed : "
    	                + this.getHostName()
    	                + ":"
    	                + this.getSmtpPort();

    	            throw new EmailException(msg, t);
    	        }
    	    }

}
