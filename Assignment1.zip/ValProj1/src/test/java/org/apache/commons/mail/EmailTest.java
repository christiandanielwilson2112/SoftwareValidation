package org.apache.commons.mail;

import java.util.*;

import javax.mail.*;

import org.junit.*;

import junit.framework.TestCase;

public class EmailTest extends TestCase{
	protected SimpleEmail emailTest; 
	protected Session session;
	/**
	 * Initializes emailTest from SampleEmail
	 */
	public void setUp() {
		emailTest = new SimpleEmail();
	}
	/**
	 * Tests addBcc function
	 */
	@Test
	public void testAddBcc() {
		String [] emails = new String[]{"abc@yahoo.com", "def@gmail.com", "ghi@msn.com", "jlk@live.com", "bozo@xyz.com"};
		try {
			emailTest.addBcc(emails);
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests addCc function
	 */
	@Test
	public void testAddCc() {
		try {
		emailTest.addCc("abc@yahoo.com");
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests addHeader function with good data
	 */
	@Test
	public void testAddHeader() {
		try {
			emailTest.addHeader("Christian", "Star Wars");
		} catch (IllegalArgumentException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests addHeader function with empty data
	 */
	@Test
	public void testAddHeaderBad() {
		try {
			emailTest.addHeader("", "");
		} catch (IllegalArgumentException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests addReplyTo function
	 */
	@Test
	public void testAddReplyTo() {
		try {
			emailTest.addReplyTo("abc@yahoo.com", "Christian");
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests buildMimeMessage
	 */
	@Test
	public void testBuildMimeMessage() {
		try {
			emailTest.setHostName("Test");
			Session session = emailTest.getMailSession();
			emailTest.setMailSession(session);
			emailTest.setMsg("Message");
			emailTest.setSubject("Test");
			emailTest.updateContentType("UTF-8");
			emailTest.addHeader("name", "value");
			emailTest.addTo("test@gmail.com");
			emailTest.setFrom("test@hotmail.com");
			emailTest.addBcc("test@yahoo.com");
			emailTest.addCc("test@yahoo.com");
			emailTest.addReplyTo("test@yahoo.com");
			emailTest.setPopBeforeSmtp(true, "newPopHost", "newPopUsername", "newPopPassword");
			emailTest.buildMimeMessage();
		} catch (EmailException e) {
			System.out.print(e.toString());
		} 
	}
	/**
	 * Tests buildMimeMessage with bad data
	 */
	@Test
	public void testBuildMimeMessageBad() {
		try {
			emailTest.setHostName("Host");
			Session session = emailTest.getMailSession();
			emailTest.setMailSession(session);
			emailTest.updateContentType(null);
			emailTest.addHeader("name", "value");
			emailTest.addTo("test@gmail.com");
			emailTest.setFrom("test@hotmail.com");
			emailTest.addReplyTo("test@yahoo.com");
			emailTest.setPopBeforeSmtp(true, "newPopHost", "newPopUsername", "newPopPassword");
			emailTest.buildMimeMessage();
		} catch (EmailException e) {
			System.out.print(e.toString());
		} 
	}
	
	/**
	 * Tests getHostName function with good data
	 */
	@Test
	public void testGetHostName() {
		emailTest.setHostName("aHostName");
		emailTest.getHostName();
	}
	/**
	 * Tests getHostName function with empty data
	 */
	@Test
	public void testGetHostNameBad() {
		emailTest.getHostName();
	}
	/**
	 * Tests getMailSession function with good data
	 */
	@Test
	public void testGetMailSession() {
		try {
			emailTest.setHostName("aHostName");
			emailTest.getMailSession();
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests getMailSession function with empty data
	 */
	@Test
	public void testGetMailSessionBad() {
		try {
			emailTest.getMailSession();
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests getSentDate function
	 */
	@Test
	public void testGetSentDate() {
		Date date = new Date();
		emailTest.setSentDate(date);
		emailTest.getSentDate();
	}
	/**
	 * Tests getSocketConnectionTimeout function
	 */
	@Test
	public void testGetSocketConnectionTimeout() {
		emailTest.getSocketConnectionTimeout();
	}
	/**
	 * Tests send function with good data
	 */
	@Test
	public void testSend() {
		try {	
			emailTest = new EmailMock();
			emailTest.setHostName("test");
			Session session = emailTest.getMailSession();
			emailTest.setMailSession(session);
			emailTest.setMsg("Message");
			emailTest.setSubject("Test");
			emailTest.updateContentType("UTF-8");
			emailTest.addHeader("name", "value");
			emailTest.addTo("test@gmail.com");
			emailTest.setFrom("test@hotmail.com");
			emailTest.addBcc("test@yahoo.com");
			emailTest.addCc("test@yahoo.com");
			emailTest.addReplyTo("test@yahoo.com");
			emailTest.send();
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests send function with bad data
	 */
	@Test
	public void testSendBad() {
		try {	
			emailTest.setHostName("test");
			Session session = emailTest.getMailSession();
			emailTest.setMailSession(session);
			emailTest.updateContentType(null);
			emailTest.addHeader("name", "value");
			emailTest.setFrom("test@hotmail.com");
			emailTest.setPopBeforeSmtp(true, "newPopHost", "newPopUsername", "newPopPassword");
			emailTest.send();
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	
	/**
	 * Tests setFrom function
	 */
	@Test
	public void testSetFrom() {
		try{
			emailTest.setFrom("abc@yahoo.com");
		} catch (EmailException e) {
			System.out.print(e.toString());
		}
	}
	/**
	 * Tests updateConentType function with good data
	 */
	@Test
	public void testUpdateContentType() {
		emailTest.updateContentType("text/");
	}
	/**
	 * Tests updateConentType function with empty data
	 */
	@Test
	public void testUpdateContentTypeBad() {
		emailTest.updateContentType("");
	}
	/**
	 * Tests updateConentType function changing content
	 */
	@Test
	public void testUpdateContentTypeContent() {
		emailTest.setCharset("UTF-8");
		emailTest.updateContentType("text/test");
	}
	/**
	 * Tests updateConentType function changing charset
	 */
	@Test
	public void testUpdateContentTypeCharset() {
		emailTest.updateContentType("; charset= ;");
		emailTest.updateContentType(": charset= ;");
	}
	/**
	 * Removes emailTest
	 */
	@After
	public void tearDown() {
		emailTest = null;
	}
}