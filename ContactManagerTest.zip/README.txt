Christian Wilson
CS 4723
Software Validation
12/11/17

My scripts run from the home screen to open the contact manager. It might be a little slow but all the scripts work. 
