import sys
import time

from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice

device = MonkeyRunner.waitForConnection()

#start of prog
#open contacts
device.touch(334, 1654, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

#create contact
device.touch(553, 836, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.touch(400, 902, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.type('Christian')
device.press('KEYCODE_SPACE', MonkeyDevice.DOWN_AND_UP)
device.type('Wilson')
time.sleep(1)

device.press('KEYCODE_ENTER', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.type('2102223333')
time.sleep(1)

device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(5)
#end create contact

#starts call
device.touch(440, 770, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(135, 1306, MonkeyDevice.DOWN_AND_UP)
time.sleep(6)
    
device.touch(538, 1572, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.press('KEYCODE_BACK', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)
#ends call

#delete
#selects contact
device.touch(516, 770, MonkeyDevice.DOWN_AND_UP)
time.sleep(4)

#delete contact
device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(999, 150, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(780, 995, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

#goes back to home
device.press('KEYCODE_HOME', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

