import sys
import time

from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice

device = MonkeyRunner.waitForConnection()

#start of prog
#open contacts
device.touch(334, 1654, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

#create contact
device.touch(553, 836, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.touch(400, 902, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.type('Christian')
device.press('KEYCODE_SPACE', MonkeyDevice.DOWN_AND_UP)
device.type('Wilson')
time.sleep(1)

device.press('KEYCODE_ENTER', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.type('2102223333')
time.sleep(1)

device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(5)
#end create contact

#sort
device.press('KEYCODE_BACK', MonkeyDevice.DOWN_AND_UP)
time.sleep(5)

 # making sure the sorting starts with first name
device.touch(1003, 153, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(618, 588, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(430, 330, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(425, 925, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.press('KEYCODE_BACK', MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

 # creating new contact
device.touch(940, 1640, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.touch(400, 902, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)

device.type('Stu')
device.press('KEYCODE_SPACE', MonkeyDevice.DOWN_AND_UP)
device.type('Pickles')
time.sleep(1)

device.press('KEYCODE_ENTER', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.type('2541234567')
time.sleep(1)

device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(5)

device.press('KEYCODE_BACK', MonkeyDevice.DOWN_AND_UP)
time.sleep(5)
#end create 2nd contact

    #switching sort to last name
device.touch(1003, 153, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(618, 588, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(430, 330, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.touch(450, 1070, MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
    
device.press('KEYCODE_BACK', MonkeyDevice.DOWN_AND_UP)
time.sleep(2)
#end sort

#delete 1
#selects contact
device.touch(516, 770, MonkeyDevice.DOWN_AND_UP)
time.sleep(4)

#delete contact
device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(999, 150, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(780, 995, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)
#delete 1

#delete 2
#selects contact
device.touch(516, 770, MonkeyDevice.DOWN_AND_UP)
time.sleep(4)

#delete contact
device.touch(1003, 155, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(999, 150, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)

device.touch(780, 995, MonkeyDevice.DOWN_AND_UP)
time.sleep(1)
#delete 2

#goes back to home
device.press('KEYCODE_HOME', MonkeyDevice.DOWN_AND_UP)
time.sleep(1)
